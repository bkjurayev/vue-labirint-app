<template>
    <footer class="footer">
        <div class="footer__container _container">
            <div class="footer__body">
                <div class="footer__logo">
                    <img src="../assets/images/Logo.png" alt="logo">
                </div>
                <div class="footer__socials">
                    <img src="../assets/images/icons/socials/instagram.png" alt="instagram">
                    <img src="../assets/images/icons/socials/facebook.png" alt="facebook">
                    <img src="../assets/images/icons/socials/telegram.png" alt="telegram">
                </div>
                <div class="footer__menu">
                    <ul class="footer__menu__list">
                        <li class="footer__menu__list__link">Kurslar</li>
                        <li class="footer__menu__list__link">Afzalliklar</li>
                        <li class="footer__menu__list__link">O'quvchilar</li>
                        <li class="footer__menu__list__link">Ekskursiya</li>
                        <li class="footer__menu__list__link">Filiallar</li>
                        <li class="footer__menu__list__link">Jamoa</li>
                        <li class="footer__menu__list__link">Ustozlar</li>
                        <li class="footer__menu__list__link">Rahbar</li>
                        <li class="footer__menu__list__link">Tadbirlar</li>
                        <li class="footer__menu__list__link">Yangiliklar</li>
                        <li class="footer__menu__list__link">Blog</li>
                        <li class="footer__menu__list__link">Savollar</li>
                    </ul>
                </div>
            </div>
        </div>
    </footer>
</template>