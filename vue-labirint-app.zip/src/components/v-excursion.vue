<template>
  <section class="excursion">
    <div class="excursion__container _container">
      <h1 class="excursion__title _title">
        O’quv markazimiz bo'ylab ekskursiyaga marhamat!
      </h1>
      <p class="excursion__subtitle">
        O’z Ingliz tili darajangizni bepul tekshirish va o’quv markazlarimizdan
        biriga bepul ekskursiyaga tashrif buyurish uchun o’z ma’lumotlaringizni
        qoldiring
      </p>
      <div class="excursion__body">
        <form action="" class="excursion__form">
            <input class="excursion__form__input" type="text" placeholder="Ism">
            <input class="excursion__form__input" type="text" placeholder="Familiya">
            <input class="excursion__form__input" type="number" placeholder="Telefon raqamingiz">
            <textarea  class="excursion__form__input" rows="6" cols="20" placeholder="Fikr va takliflar"></textarea>
            <button class="excursion__form__btn _btn">Jo'natish</button>
            <p class="excursion__form__info">Ma'lumotlaringiz 3-shaxslarga berilmaydi</p>
        </form>
        <div class="excursion__img"></div>
      </div>
    </div>
  </section>
</template>
