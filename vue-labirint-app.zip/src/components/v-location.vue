<template>
  <section class="location">
    <div class="location__container _container">
      <h1 class="location__title _title">
        “Labirint” o’quv markazi qayerda joylashgan?
      </h1>
      <p class="location__subtitle">Qanday qilib biz bilan bog'lansa bo'ladi?</p>
    </div>
  </section>
</template>
