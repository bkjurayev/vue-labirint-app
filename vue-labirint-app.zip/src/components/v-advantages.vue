<template>
    <section class="main__advantages advantages">
        <div class="advantages__container _container">
            <h1 class="advantages__title _title">"Labirint" o'quv markazi afzalliklari</h1>
            <p class="advantages__subtitle">Har bir o'quvchimiz quyidagi afzalliklarga ega bo'ladi</p>
            <div class="advantages__body">
                <div class="advantages__list">
                    <div class="advantages__item">
                        <img src="../assets/images/icons/advantages/User.svg" alt="">
                        O'quvchilarni imtihonlarga tayyorlash bo'yicha 3-15 yillik tajribaga ega ustozlar (IELTS 8,5 gacha)
                    </div>
                    <div class="advantages__item">
                        <img src="../assets/images/icons/advantages/Crown.svg" alt="">
                        Academic Support - ikkinchi o'qituvchi xizmati. Darsdan tashqari bepul qo'shimcha mashg'ulotlar olish imkoniyati
                    </div>
                    <div class="advantages__item">
                        <img src="../assets/images/icons/advantages/CircleWavyCheck.svg" alt="">
                        Ota-ona va o’quvchi o'z uy vazifalari, baho va natijalarini kuzatib borishi uchun maxsus platformada shaxsiy kabinet
                    </div>
                    <div class="advantages__item">
                        <img src="../assets/images/icons/advantages/Flag.svg" alt="">
                        O'zbekistonda yagona kuchli o'qitish tizimi va Buyuk Britaniya o'quv dasturi
                    </div>
                    <div class="advantages__item">
                        <img src="../assets/images/icons/advantages/GraduationCap.svg" alt="">
                        Tadbirlar - hafta davomida va yakshanba kungi bepul trening, master-class, speaking club'lar
                    </div>
                    <div class="advantages__item">
                        <img src="../assets/images/icons/advantages/Handshake.svg" alt="">
                        Darsdan tashqari qo'shimcha dars tayyorlash uchun co-working joylar
                    </div>
                    <div class="advantages__item">
                        <img src="../assets/images/icons/advantages/IdentificationCard.svg" alt="">
                        IELTS MOCK CLUB – har yakshanba kuni bepul IELTS treninglari va IELTS MOCK imtihoni
                    </div>
                    <div class="advantages__item">
                        <img src="../assets/images/icons/advantages/NotePencil.svg" alt="">
                        Volontyorlik - Cambridge o’quv markazining “HOPE” xayriya fondi tadbirlarida volontyorlik qilish imkoniyati
                    </div>
                    <div class="advantages__item">
                        <img src="../assets/images/icons/advantages/Users.svg" alt="">
                        Shogird tushish - Ingliz tilini yaxshi o’zlashtirgan o’quvchilarda Cambridge hodimlariga shogird tushib, 3 oy davomida ish o’rganish imkoniyati
                    </div>
                </div>
            </div>
            <div class="advantages__btn _btn">Kursga yozilish</div>
        </div>
    </section>
</template>>