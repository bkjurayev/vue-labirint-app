<template>
  <header class="header">
    <div class="header__container _container">
      <div class="header__body">
        <div class="header__logo">
          <img src="../assets/images/Logo.png" alt="Logo" />
        </div>
        <nav class="header__navbar navbar">
          <ul class="navbar__lists">
            <li class="navbar__item">
              <a href="" class="navbar__link">Kusrlar</a>
            </li>
            <li class="navbar__item">
              <a href="" class="navbar__link">Jamoa</a>
            </li>
            <li class="navbar__item">
              <a href="" class="navbar__link">Yangiliklar</a>
            </li>
            <li class="navbar__item">
              <a href="" class="navbar__link">Blog</a>
            </li>
            <li class="navbar__item">
              <a href="" class="navbar__link oferta">Oferta</a>
            </li>
          </ul>
        </nav>
        <div class="header__contacts contacts">
          <div class="contacts__item phone">
            <a href="tel:+99884748080" class="phone__link">
                <span class="phone__icon">
                    <img src="../assets/images/icons/call.png" alt="Phone" />
                </span>
                <span class="phone__number">(88) 474 8080</span>
            </a>            
          </div>
          <div class="contacts__item btn-accaunt _btn">
            <img src="../assets/images/icons/user-large-solid.svg" alt="User" />
            <span>Shaxsiy kabinet</span>            
          </div>
          <div class="contacts__item btn-pay _btn">
            <img src="../assets/images/icons/paypal-brands.svg" alt="Payment" />
            <span>Pay online</span>            
          </div>
        </div>
        <div class="header__burger burger">
            <span class="burger__item"></span>
            <span class="burger__item"></span>
            <span class="burger__item"></span>
        </div>
      </div>
    </div>
  </header>
  <main class="main">
    <div class="main__container _container">
      <div class="main__top top-main">
        <div class="top-main__content">
          <h1 class="top-main__content__title"><strong>IELTS 7.0 va undan yuqori ballni</strong> birinchi imtihonning o'zidayoq qo'lga kiriting</h1>
          <p class="top-main__content__subtitle">Labirint o’quv markazida faqat kuchli maqsadga ega o'quvchilarni uchratasiz.</p>
          <div class="top-main__content__btn _btn">
            Birinchi darsga yozilish
          </div>
        </div>    
        <div class="top-main__video">
          <img src="../assets/images/student.png" alt="Student" class="top-main__video__img">
          <div class="top-main__video__btn">
            <div class="top-main__video__btn__img">
              <img src="../assets/images/icons/play.svg" alt="play">
            </div>
            <p class="top-main__video__btn__text">O'quv markazimiz haqida bilishni hohlaysizmi?</p>
          </div>
        </div>    
      </div>
    </div>
  </main>
</template>
