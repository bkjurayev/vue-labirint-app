<template>
  
  <VHeader />

  <main class="main">
    <VSlider />

    <VAdvantages />

    <VExcursion />

    <VLocation />
    
    <VFooter />
  </main>
  
</template>

<script setup>
  import VHeader from "@/components/v-header.vue";
  import VSlider from "@/components/v-slider.vue";
  import VAdvantages from "@/components/v-advantages.vue";
  import VExcursion from "@/components/v-excursion.vue";
  import VLocation from "@/components/v-location.vue";
  import VFooter from "@/components/v-footer.vue";

</script>
